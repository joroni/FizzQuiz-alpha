$(document).ready(function () {
    $('#loader').show();
    setTimeout(myFunction, 3000);

    function myFunction() {

        $('#loader').hide();

    }

});

function loaderSpin() {

    $('#loader').show();
    setTimeout(myFunction, 3000);

    function myFunction() {

        $('#loader').hide();

    }

}