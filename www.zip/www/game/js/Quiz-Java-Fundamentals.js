var init = { 
     'questions': [ 
       {
           'question': 'True or False: Java is a strongly typed language.',
           'answers': ['True', 'False'],
       	   'correctAnswer': 1
       },
       {
           'question': 'In Java Strings are primitive types.',
           'answers': ['True', 'False'],
       	   'correctAnswer': 2
       }
     ],
     
	  'resultComments' :  
	  {
		   perfect: 'You\'re awesome enough to just walk into Mordor, aren&#39;t you?',
			 excellent: 'My PRECIOUS!! You were outstanding!',
			 good: 'Good enough, but beware the power of the ring.',
			 average: 'An orc would have performed just as good as you!',
			 bad: 'Is your mind poisoned by the ring?',
			 poor: 'Is your mind poisoned by the ring?',
			 worst: 'What is this new trolling?!'
	  }

 };
